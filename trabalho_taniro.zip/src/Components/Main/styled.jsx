import styled from "styled-components";

export const AreaMain = styled.main`
  // css main
  .h2_main 
  {
    font-size: 2rem;
    text-align: center;
    color: red;
  }
  display: grid;

  .container {
    width: 96%;
    margin-top: 2rem;
    padding-left: 2%;
    padding-right: 2%;

    display: flex;
    flex-wrap: wrap;
    /* align-items: center; */
    justify-content: space-around;
    /* background-color: #333; */
    /* justify-items: center; */
    /* justify-content: space-around; */


    .subcontainer {
  
      justify-content: space-around;
      width: 80%;
      display: flex;
      flex-wrap: wrap;
      align-items: center;

        .card {
          background-color: #fff;
          margin-bottom: auto;
          max-width: calc(49% - 1rem);
          box-shadow: 0px 0px 5px #aaa;
          .h2 {
            color: red;
            font-size: 2rem;
            padding: .5rem .5rem 0 .5rem;
          }
          .paragrafo {
            font-size: 1.25rem;
            text-align: justify;
            padding: 1rem;
          }
          .image {
            padding-right: 1rem;
            /* height: 30%; */
            max-width: 70%;
            float: left;
          }
        }
      }
  
    .aside {
      display: inline-block;
      min-width: 20%;
      max-width: 20%;
      .card_aside {
        background-color: #fff;
        display: inline-block;
        max-width: 100%;
        box-shadow: 0px 0px 5px #aaa;
        margin-bottom: 2rem;
        .h2_aside {
          color: red;
          font-size: 2rem;
          text-align: center;
        }
        .paragrafo_aside {
          text-align: justify;
          font-size: 1rem;
          padding: 0 1rem 1rem 1rem;
        }
        .image_aside {
          /* padding-right: 1rem; */
          max-width: 100%;
          float: left;
        }
      }
    }

    @media screen and (max-width: 1200px){
      .subcontainer {
        padding-top: 1%;
        width: 96%;
        .card {
        margin-top: 2rem;
        width: 80%;
        max-width: 80%;
          .image {
            width: 100%;
          }
        }
      }
      .aside {
      min-width: 40%;
      max-width: 40%;
      padding-left: 2%;
        .card_aside {

          max-width: 96%;
        }
      }
    }
    
    @media screen and (max-width: 991px){
    .subcontainer {
      padding-top: 3%;
      width: 96%;
      
        .card {
        min-width: 90%;
        max-width: 100%;
          .h2 {
          text-align: center;
        }
        .image {
          width: 100%;
        }
      }
    }
    
    .aside {
      min-width: 90%;
      max-width: 90%;
      padding-left: 3%;
      .card_aside {

        max-width: 96%;
      }
    }
  }
  @media screen and (max-width: 532px){
    .subcontainer {
      
      .card {
        margin-top: 3rem;
        .image {
          max-width: 100%;
        }
      }
    }
  }
}
  
  
  

`;